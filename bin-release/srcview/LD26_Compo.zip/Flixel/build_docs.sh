#! /bin/sh
/Applications/Adobe\ Flash\ Builder\ 4\ Plug-in/sdks/4.0.0/bin/asdoc -source-path . -doc-sources . -output docs